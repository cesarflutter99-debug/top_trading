--------------------------------------------------------------------------------
-- VERIFICACIONES (solo lectura, no cambian nada). Correr una por una.
-- Fecha: 2026-11-07
--------------------------------------------------------------------------------

-- 1. ¿anon puede ejecutar funciones sensibles? (todas deben dar false)
select 'admin_reembolsar_pedido' as funcion,
       has_function_privilege('anon', 'public.admin_reembolsar_pedido(uuid,text)', 'execute') as anon_puede
union all select 'fn_cancelar_pedido',
       has_function_privilege('anon', 'public.fn_cancelar_pedido(uuid,text,text)', 'execute')
union all select 'afiliado_dashboard_resumen',
       has_function_privilege('anon', 'public.afiliado_dashboard_resumen(uuid)', 'execute')
union all select 'admin_usuarios_activos',
       has_function_privilege('anon', 'public.admin_usuarios_activos()', 'execute');

-- 2. Columnas de `planes` que anon puede leer (no deben aparecer numero_tarjeta,
--    numero_telefono_pago ni qr_url)
select column_name, privilege_type
from information_schema.column_privileges
where table_schema = 'public' and table_name = 'planes' and grantee = 'anon'
order by column_name;

-- 3. Funciones con permisos de administrador que NO verifican rol ni usuario
--    (deberían quedar solo las públicas: carruseles, feed, negocios_cercanos,
--    anuncio_registrar_clic, vendedor_valoraciones, codigo_afiliado_disponible,
--    auxiliares fn_*, y las de mantenimiento ya cerradas a usuarios)
select p.oid::regprocedure as funcion,
       has_function_privilege('anon', p.oid, 'execute') as anon_puede
from pg_proc p
where p.pronamespace = 'public'::regnamespace and p.prosecdef
  and p.prorettype <> 'trigger'::regtype
  and p.prosrc !~* '(es_admin\(|admins|admin_tiene_permiso|es_superadmin|NO_AUTORIZADO|auth\.uid\(\))'
order by 1;

-- 4. procesar_pedido_completado debe ser SECURITY DEFINER (prosecdef = true)
select proname, prosecdef from pg_proc where proname = 'procesar_pedido_completado';

-- 5. Triggers de protección presentes
select c.relname as tabla, t.tgname
from pg_trigger t join pg_class c on c.oid = t.tgrelid
where not t.tgisinternal
  and t.tgname in ('trg_tiendas_proteger_columnas', 'trg_negocios_proteger_columnas',
                   'trg_afiliados_saldo_inicial', 'trg_proteger_columnas_sensibles_afiliado',
                   'trg_anuncios_update', 'trg_anuncios_insert');

-- 6. Políticas de notificaciones (no debe existir usuarios_autenticados_insertan_notificaciones)
select policyname, cmd from pg_policies
where schemaname = 'public' and tablename = 'notificaciones';

-- 7. Respaldo de funciones reescritas por el FIX 04
select nombre, guardado_en from public.respaldo_funciones order by nombre;

-- 8. Trabajos programados: últimas ejecuciones (todas deben decir succeeded)
select jobid, status, left(return_message, 120) as mensaje, start_time
from cron.job_run_details order by start_time desc limit 20;

-- 9. Edge Function eliminar-tiendas-vencidas: revisar DESPUÉS de las 08:10 UTC
--    (el job invocar_eliminar_tiendas_vencidas corre a esa hora). status_code 200 = bien.
select status_code, left(content::text, 200) as respuesta, created
from net._http_response order by created desc limit 5;

-- 10. Pendientes de revisar todavía (no corridas)
-- 10a. Tablas sin RLS
select tablename from pg_tables where schemaname = 'public' and not rowsecurity;
-- 10b. Claves foráneas sin índice
select c.conrelid::regclass as tabla, c.conname as relacion
from pg_constraint c
where c.contype = 'f' and c.connamespace = 'public'::regnamespace
  and not exists (select 1 from pg_index i where i.indrelid = c.conrelid and i.indkey[0] = c.conkey[1])
order by 1;
