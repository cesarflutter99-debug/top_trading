--------------------------------------------------------------------------------
-- ROLLBACK de los fixes del 2026-11-07
-- TODO ESTÁ COMENTADO a propósito: descomenta SOLO la sección que necesites.
--------------------------------------------------------------------------------

-- 01  Índices y RPC de optimización
--   DROP INDEX IF EXISTS public.idx_anuncios_feed_opt, public.idx_negocios_feed_opt,
--     public.idx_productos_tienda_precio, public.idx_pedidos_tienda_estado_fecha,
--     public.idx_anuncio_likes_compuesto, public.idx_notificaciones_usuario_leida;
--   DROP FUNCTION IF EXISTS public.fn_admin_dashboard_resumen_optimizado();
--   DROP FUNCTION IF EXISTS public.fn_vendedor_dashboard_resumen_optimizado(uuid);

-- 02  Planes: volver a permitir leer todas las columnas sin sesión (NO recomendado)
--   GRANT SELECT ON public.planes TO anon;

-- 03  Devolver a anon el acceso a las funciones
--   GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO anon;

-- 04  Restaurar las funciones originales (las guardadas en respaldo_funciones)
--   DO $$ DECLARE r record; BEGIN
--     FOR r IN SELECT definicion FROM public.respaldo_funciones LOOP EXECUTE r.definicion; END LOOP;
--   END $$;

-- 05  Puntos y saldo de afiliados
--   DROP TRIGGER IF EXISTS trg_afiliados_saldo_inicial ON public.afiliados;
--   ALTER FUNCTION public.procesar_pedido_completado() SECURITY INVOKER;

-- 06  Funciones de mantenimiento: devolver una función concreta a usuarios
--   GRANT EXECUTE ON FUNCTION public.fn_registrar_uso_plan_gratis(uuid) TO authenticated;
--   (repetir con la función que haya fallado)

-- 07  Notificaciones y funciones internas
--   CREATE POLICY usuarios_autenticados_insertan_notificaciones
--     ON public.notificaciones FOR INSERT TO authenticated WITH CHECK (true);
--   GRANT EXECUTE ON FUNCTION public.fn_eliminar_tienda_individual_plan_vencido(uuid) TO authenticated;

-- 08  Triggers de tiendas y negocios
--   DROP TRIGGER IF EXISTS trg_tiendas_proteger_columnas ON public.tiendas;
--   DROP TRIGGER IF EXISTS trg_negocios_proteger_columnas ON public.negocios;
