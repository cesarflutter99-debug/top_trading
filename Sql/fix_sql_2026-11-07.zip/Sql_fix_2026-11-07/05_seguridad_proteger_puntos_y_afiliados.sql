--------------------------------------------------------------------------------
-- FIX 05 - Seguridad: puntos de tienda y saldo inicial de afiliados
-- Fecha: 2026-11-07
-- 1) procesar_pedido_completado pasa a SECURITY DEFINER: así sube los puntos
--    de la tienda con permisos propios y no con los del vendedor. Es requisito
--    para poder bloquear después los puntos a los usuarios (FIX 08).
-- 2) Un afiliado creado desde la app siempre empieza con saldo_cup = 0
--    (el trigger existente solo protegía el UPDATE, no el INSERT).
--------------------------------------------------------------------------------
ALTER FUNCTION public.procesar_pedido_completado() SECURITY DEFINER;
ALTER FUNCTION public.procesar_pedido_completado() SET search_path = public;

CREATE OR REPLACE FUNCTION public.afiliados_saldo_inicial()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF current_user IN ('authenticated', 'anon') AND NOT public.es_admin() THEN
    NEW.saldo_cup := 0;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_afiliados_saldo_inicial ON public.afiliados;
CREATE TRIGGER trg_afiliados_saldo_inicial
BEFORE INSERT ON public.afiliados
FOR EACH ROW EXECUTE FUNCTION public.afiliados_saldo_inicial();

-- Revertir: ver 99_rollback_todo.sql (sección 05)
