--------------------------------------------------------------------------------
-- FIX 04 - Seguridad: verificación de rol / dueño DENTRO de las funciones
-- Fecha: 2026-11-07
-- Problema: funciones como admin_reembolsar_pedido, fn_cancelar_pedido,
-- admin_buscar_usuario_por_email, vendedor_*, afiliado_* y comprador_* no
-- comprobaban quién las llamaba (cualquier usuario con sesión podía usarlas
-- con el id de otro).
-- Solución: se añade un chequeo al inicio de cada una (admins siguen pasando;
-- las llamadas sin usuario, como cron y Edge Functions, también).
-- Respaldo: la definición original queda en public.respaldo_funciones.
-- Solo reescribe funciones plpgsql que aún no verifican nada (idempotente).
--------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.respaldo_funciones (
  oid_func    oid PRIMARY KEY,
  nombre      text,
  definicion  text,
  guardado_en timestamptz DEFAULT now()
);
ALTER TABLE public.respaldo_funciones ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.respaldo_funciones FROM anon, authenticated;

DO $$
DECLARE
  r     record;
  v_def text;
  v_chk text;
BEGIN
  FOR r IN
    SELECT p.oid, p.proname,
           CASE
             WHEN p.proname LIKE 'admin\_%' THEN 'admin'
             WHEN p.proname IN ('afiliado_dashboard_resumen', 'afiliado_comisiones', 'afiliado_retiros') THEN 'afiliado'
             WHEN p.proname IN ('comprador_dashboard_resumen', 'comprador_pedidos') THEN 'comprador'
             WHEN p.proname LIKE 'vendedor\_%' AND p.proname <> 'vendedor_valoraciones' THEN 'vendedor'
             WHEN p.proname = 'fn_cancelar_pedido' THEN 'pedido'
           END AS tipo
    FROM pg_proc p
    JOIN pg_language l ON l.oid = p.prolang
    WHERE p.pronamespace = 'public'::regnamespace
      AND p.prokind = 'f'
      AND l.lanname = 'plpgsql'
      AND p.prorettype <> 'trigger'::regtype
      AND p.proname NOT IN ('admin_tiene_permiso', 'es_admin', 'es_superadmin')
      AND p.prosrc !~* '(es_admin\(|from\s+(public\.)?admins|admin_tiene_permiso|es_superadmin|NO_AUTORIZADO)'
  LOOP
    CONTINUE WHEN r.tipo IS NULL;

    v_chk := CASE r.tipo
      WHEN 'admin' THEN
        $c$ if auth.uid() is not null and not public.es_admin() then raise exception 'SOLO_ADMIN'; end if; $c$
      WHEN 'afiliado' THEN
        $c$ if auth.uid() is not null and not public.es_admin()
              and not exists (select 1 from public.afiliados a where a.id_afiliado = p_id_afiliado and a.user_id = auth.uid())
            then raise exception 'NO_AUTORIZADO'; end if; $c$
      WHEN 'comprador' THEN
        $c$ if auth.uid() is not null and not public.es_admin()
              and p_id_comprador is distinct from auth.uid()
            then raise exception 'NO_AUTORIZADO'; end if; $c$
      WHEN 'vendedor' THEN
        $c$ if auth.uid() is not null and not public.es_admin()
              and not exists (select 1 from public.tiendas t where t.id_tienda = p_id_tienda and t.owner_id = auth.uid())
            then raise exception 'NO_AUTORIZADO'; end if; $c$
      WHEN 'pedido' THEN
        $c$ if auth.uid() is not null and not public.es_admin()
              and not exists (select 1 from public.pedidos pe left join public.tiendas t on t.id_tienda = pe.id_tienda
                              where pe.id_pedido = p_id_pedido and (pe.id_comprador = auth.uid() or t.owner_id = auth.uid()))
            then raise exception 'NO_AUTORIZADO'; end if; $c$
    END;

    v_def := pg_get_functiondef(r.oid);
    IF v_def !~* '\mbegin\M' THEN
      RAISE NOTICE 'Omitida (sin BEGIN): %', r.proname;
      CONTINUE;
    END IF;

    INSERT INTO public.respaldo_funciones (oid_func, nombre, definicion)
    VALUES (r.oid, r.proname, v_def)
    ON CONFLICT (oid_func) DO NOTHING;

    EXECUTE regexp_replace(v_def, '\mbegin\M', 'begin ' || v_chk, 'i');
    RAISE NOTICE 'Protegida: % (%)', r.proname, r.tipo;
  END LOOP;
END $$;

-- Revertir: ver 99_rollback_todo.sql (sección 04)
