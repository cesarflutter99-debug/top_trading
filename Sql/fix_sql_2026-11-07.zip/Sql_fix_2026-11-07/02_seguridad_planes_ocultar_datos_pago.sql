--------------------------------------------------------------------------------
-- FIX 02 - Seguridad: ocultar datos de pago de `planes` a usuarios sin sesión
-- Fecha: 2026-11-07
-- Problema: la política planes_lectura_publica dejaba leer TODAS las columnas
-- (numero_tarjeta, numero_telefono_pago, qr_url) a cualquiera sin cuenta.
-- Solución: permisos por columna para el rol anon. Las políticas no se tocan.
--------------------------------------------------------------------------------
REVOKE SELECT ON public.planes FROM anon;

GRANT SELECT (
  id_plan, nombre, precio_usd, limite_productos, activo, creado_en,
  descripcion, es_gratis, duracion_dias, codigo, ranuras_anuncios, features
) ON public.planes TO anon;

-- Comprobar (debe dar "permission denied for table planes"):
--   set role anon;
--   select numero_tarjeta from public.planes limit 1;
--   reset role;
--
-- Revertir (solo si una pantalla pública se rompe):
--   GRANT SELECT ON public.planes TO anon;
