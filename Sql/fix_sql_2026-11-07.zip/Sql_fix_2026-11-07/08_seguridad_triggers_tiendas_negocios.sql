--------------------------------------------------------------------------------
-- FIX 08 - Seguridad: proteger columnas sensibles de `tiendas` y `negocios`
-- Fecha: 2026-11-07
-- ESTADO: CONFIRMAR si se corrió. Requisitos antes de correrlo:
--   a) FIX 05 aplicado (procesar_pedido_completado = SECURITY DEFINER).
--   b) En la app, activarPlanGratis() y crearTiendaConPlan() de
--      tiendas_service.dart no se llaman desde ninguna pantalla. Si se llaman,
--      activarPlanGratis cambia plan/estado desde el cliente y este trigger la
--      bloqueará.
-- Efecto: un usuario normal NO puede cambiar plan, estado, vigencia, puntos ni
-- valoraciones de su tienda; una tienda nueva siempre entra 'pending' sin
-- vigencia ni puntos. Nombre, logo, portada, teléfono, descripción, ubicación
-- y código de afiliado siguen editables. Admin, funciones internas, cron y
-- Edge Functions pasan igual.
--------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.tiendas_proteger_columnas()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF current_user NOT IN ('authenticated', 'anon') THEN
    RETURN NEW;
  END IF;
  IF public.es_admin() OR public.admin_tiene_permiso('aprobar_tiendas') THEN
    RETURN NEW;
  END IF;

  IF TG_OP = 'INSERT' THEN
    NEW.estado := 'pending';
    NEW.plan_expira_en := NULL;
    NEW.puntos_totales := 0;
    NEW.puntos_semanales := 0;
  ELSIF NEW.plan IS DISTINCT FROM OLD.plan
     OR NEW.estado IS DISTINCT FROM OLD.estado
     OR NEW.plan_expira_en IS DISTINCT FROM OLD.plan_expira_en
     OR NEW.ultima_activacion IS DISTINCT FROM OLD.ultima_activacion
     OR NEW.puntos_totales IS DISTINCT FROM OLD.puntos_totales
     OR NEW.puntos_semanales IS DISTINCT FROM OLD.puntos_semanales
     OR NEW.plan_gratis_usado IS DISTINCT FROM OLD.plan_gratis_usado
     OR NEW.promedio_estrellas IS DISTINCT FROM OLD.promedio_estrellas
     OR NEW.total_valoraciones IS DISTINCT FROM OLD.total_valoraciones THEN
    RAISE EXCEPTION 'CAMPO_PROTEGIDO: ese dato solo lo cambia el administrador.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_tiendas_proteger_columnas ON public.tiendas;
CREATE TRIGGER trg_tiendas_proteger_columnas
BEFORE INSERT OR UPDATE ON public.tiendas
FOR EACH ROW EXECUTE FUNCTION public.tiendas_proteger_columnas();


-- negocios: solo cambios (las altas quedan pendientes de revisar los valores por defecto)
CREATE OR REPLACE FUNCTION public.negocios_proteger_columnas()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  IF current_user NOT IN ('authenticated', 'anon') OR public.es_admin() THEN
    RETURN NEW;
  END IF;
  IF NEW.estado IS DISTINCT FROM OLD.estado
     OR NEW.motivo_rechazo IS DISTINCT FROM OLD.motivo_rechazo
     OR NEW.id_dueno IS DISTINCT FROM OLD.id_dueno THEN
    RAISE EXCEPTION 'CAMPO_PROTEGIDO: ese dato solo lo cambia el administrador.';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_negocios_proteger_columnas ON public.negocios;
CREATE TRIGGER trg_negocios_proteger_columnas
BEFORE UPDATE ON public.negocios
FOR EACH ROW EXECUTE FUNCTION public.negocios_proteger_columnas();

-- Revertir al instante:
--   DROP TRIGGER IF EXISTS trg_tiendas_proteger_columnas ON public.tiendas;
--   DROP TRIGGER IF EXISTS trg_negocios_proteger_columnas ON public.negocios;
