--------------------------------------------------------------------------------
-- FIX 06 - Seguridad: funciones de mantenimiento solo para cron / Edge Functions
-- Fecha: 2026-11-07
-- Los usuarios (anon / authenticated) ya no pueden ejecutarlas. El cron corre
-- como postgres y las Edge Functions como service_role, así que siguen igual.
-- fn_registrar_uso_codigo_afiliado SÍ la usa la app: queda solo con sesión.
--------------------------------------------------------------------------------
DO $$
DECLARE f text;
BEGIN
  FOREACH f IN ARRAY ARRAY[
    'public.fn_autocancelar_pedidos_vencidos()',
    'public.anuncios_limpiar_estados()',
    'public.anuncios_avisar_por_vencer()',
    'public.purgar_notificaciones_viejas()',
    'public.procesar_limpieza_imagekit()',
    'public.fn_eliminar_tiendas_plan_gratis_vencidas()',
    'public.fn_registrar_uso_plan_gratis(uuid)'
  ]
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon, authenticated', f);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', f);
  END LOOP;
END $$;

REVOKE EXECUTE ON FUNCTION public.fn_registrar_uso_codigo_afiliado(uuid, text) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fn_registrar_uso_codigo_afiliado(uuid, text) TO authenticated, service_role;

-- Revertir una función concreta:
--   GRANT EXECUTE ON FUNCTION <nombre>(<args>) TO authenticated;
