--------------------------------------------------------------------------------
-- FIX 01 - Optimización: índices y funciones RPC de resumen (versión corregida)
-- Fecha: 2026-11-07
-- Reemplaza a Sql/optimizacion_rendimiento.sql (fallaba: fecha_fin no existe).
-- Usa las columnas y estados REALES: tiendas 'active', negocios 'activo',
-- anuncios 'aprobado', pedidos 'completado' / 'cancelado'.
-- No destructivo: solo crea índices y funciones nuevas.
--------------------------------------------------------------------------------

-- 1. ÍNDICES
DROP INDEX IF EXISTS public.idx_anuncios_feed_opt;
CREATE INDEX IF NOT EXISTS idx_anuncios_feed_opt
ON public.anuncios (vigencia_hasta DESC, creado_en DESC)
WHERE estado = 'aprobado';

CREATE INDEX IF NOT EXISTS idx_negocios_feed_opt
ON public.negocios (categoria, creado_en DESC)
WHERE estado = 'activo';

CREATE INDEX IF NOT EXISTS idx_productos_tienda_precio
ON public.productos (id_tienda, precio_usd)
WHERE es_visible = true;

CREATE INDEX IF NOT EXISTS idx_pedidos_tienda_estado_fecha
ON public.pedidos (id_tienda, estado, creado_en DESC);

CREATE INDEX IF NOT EXISTS idx_anuncio_likes_compuesto
ON public.anuncio_likes (id_anuncio, id_usuario);

CREATE INDEX IF NOT EXISTS idx_notificaciones_usuario_leida
ON public.notificaciones (id_usuario, leida, creado_en DESC);

-- 2. FUNCIONES RPC
-- A. Resumen global (solo service_role)
CREATE OR REPLACE FUNCTION public.fn_admin_dashboard_resumen_optimizado()
RETURNS TABLE (
    total_usuarios bigint,
    total_tiendas bigint,
    total_negocios bigint,
    total_anuncios bigint,
    total_pedidos bigint,
    ingresos_totales numeric
)
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE sql
STABLE
AS $$
    SELECT
        (SELECT count(*) FROM auth.users),
        (SELECT count(*) FROM public.tiendas  WHERE estado = 'active'),
        (SELECT count(*) FROM public.negocios WHERE estado = 'activo'),
        (SELECT count(*) FROM public.anuncios WHERE estado = 'aprobado'),
        (SELECT count(*) FROM public.pedidos  WHERE estado = 'completado'),
        (SELECT coalesce(sum(total_usd), 0) FROM public.pedidos WHERE estado = 'completado');
$$;

REVOKE ALL ON FUNCTION public.fn_admin_dashboard_resumen_optimizado() FROM public, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.fn_admin_dashboard_resumen_optimizado() TO service_role;

-- B. Resumen del vendedor (solo si la tienda es del usuario logueado)
CREATE OR REPLACE FUNCTION public.fn_vendedor_dashboard_resumen_optimizado(p_id_tienda uuid)
RETURNS TABLE (
    total_productos bigint,
    total_pedidos bigint,
    pedidos_pendientes bigint,
    ventas_totales numeric,
    valoracion_promedio numeric
)
SECURITY DEFINER
SET search_path = public, pg_temp
LANGUAGE sql
STABLE
AS $$
    SELECT
        (SELECT count(*) FROM public.productos
          WHERE id_tienda = t.id_tienda AND es_visible = true),
        (SELECT count(*) FROM public.pedidos
          WHERE id_tienda = t.id_tienda),
        (SELECT count(*) FROM public.pedidos
          WHERE id_tienda = t.id_tienda AND estado NOT IN ('completado', 'cancelado')),
        (SELECT coalesce(sum(total_usd), 0) FROM public.pedidos
          WHERE id_tienda = t.id_tienda AND estado = 'completado'),
        coalesce(t.promedio_estrellas, 0)
    FROM public.tiendas t
    WHERE t.id_tienda = p_id_tienda
      AND t.owner_id = auth.uid();
$$;

REVOKE ALL ON FUNCTION public.fn_vendedor_dashboard_resumen_optimizado(uuid) FROM public, anon;
GRANT EXECUTE ON FUNCTION public.fn_vendedor_dashboard_resumen_optimizado(uuid) TO authenticated, service_role;

-- 3. ESTADÍSTICAS
ANALYZE public.anuncios;
ANALYZE public.negocios;
ANALYZE public.productos;
ANALYZE public.pedidos;
ANALYZE public.anuncio_likes;
ANALYZE public.notificaciones;
