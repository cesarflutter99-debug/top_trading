--------------------------------------------------------------------------------
-- FIX 03 - Seguridad: quitar a `anon` (sin sesión) la ejecución de funciones
--          de admin, afiliado, comprador, vendedor y anuncios.
-- Fecha: 2026-11-07
-- No toca es_admin / admin_tiene_permiso / es_superadmin (las usa el RLS) ni
-- las funciones públicas (feed, carruseles, negocios_cercanos, etc.).
-- Excluye vendedor_valoraciones (puede alimentar reseñas públicas).
--------------------------------------------------------------------------------
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS firma
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace
      AND p.prokind = 'f'
      AND p.prorettype <> 'trigger'::regtype
      AND p.proname <> 'admin_tiene_permiso'
      AND (
        p.proname LIKE 'admin\_%' OR p.proname LIKE 'superadmin\_%'
        OR p.proname LIKE 'afiliado\_%' OR p.proname LIKE 'comprador\_%'
        OR p.proname LIKE 'vendedor\_%'
        OR p.proname IN (
          'fn_cancelar_pedido', 'crear_tienda_plan_gratis', 'validar_codigo_afiliado',
          'anuncio_gestion_detalle', 'anuncio_reenviar_revision', 'anuncio_renovar_standalone',
          'fn_sincronizar_anuncio_automatico_negocio'
        )
      )
      AND p.proname <> 'vendedor_valoraciones'
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon', r.firma);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO authenticated, service_role', r.firma);
  END LOOP;
END $$;

-- Revertir todo:
--   GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO anon;
