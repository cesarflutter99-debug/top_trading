--------------------------------------------------------------------------------
-- FIX 07 - Seguridad: notificaciones, funciones internas y admin_usuarios_activos
-- Fecha: 2026-11-07
-- 1) Se elimina la política que dejaba a cualquier usuario con sesión crear
--    notificaciones para otros. Los triggers (SECURITY DEFINER), el cron y las
--    Edge Functions siguen insertando normalmente. La app Flutter no inserta.
-- 2) revisar_vencimientos y fn_eliminar_tienda_individual_plan_vencido: solo
--    service_role (cron / Edge Functions).
-- 3) admin_usuarios_activos ahora exige ser admin.
--------------------------------------------------------------------------------
DROP POLICY IF EXISTS usuarios_autenticados_insertan_notificaciones ON public.notificaciones;

DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT p.oid::regprocedure AS firma
    FROM pg_proc p
    WHERE p.pronamespace = 'public'::regnamespace
      AND p.proname IN ('revisar_vencimientos', 'fn_eliminar_tienda_individual_plan_vencido')
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %s FROM PUBLIC, anon, authenticated', r.firma);
    EXECUTE format('GRANT EXECUTE ON FUNCTION %s TO service_role', r.firma);
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.admin_usuarios_activos()
RETURNS TABLE(activos_ultima_hora integer, activos_ultimas_24h integer, activos_ultimos_7dias integer, total_usuarios integer)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.es_admin() THEN
    RAISE EXCEPTION 'SOLO_ADMIN';
  END IF;
  RETURN QUERY
  SELECT
    (SELECT count(*)::int FROM auth.users WHERE last_sign_in_at >= now() - interval '1 hour'),
    (SELECT count(*)::int FROM auth.users WHERE last_sign_in_at >= now() - interval '24 hours'),
    (SELECT count(*)::int FROM auth.users WHERE last_sign_in_at >= now() - interval '7 days'),
    (SELECT count(*)::int FROM auth.users);
END;
$$;

-- Revertir: ver 99_rollback_todo.sql (sección 07)
